# Human Validation

This folder contains the human-validation artifact for the scoring pipeline.

The paper reports an AI-assisted pre-annotation followed by review and confirmation by two human annotators on a stratified sample of 50 model outputs.

Reported agreement against the automatic scorer:

- Technical failure: 100.0% agreement, Cohen's kappa = 1.000
- Governance failure: 90.0% agreement, Cohen's kappa = 0.652
- Compliance-aware failure: 90.0% agreement, Cohen's kappa = 0.722

If the full row-level annotation workbook is available, it should replace the generated summary workbook in this folder.
