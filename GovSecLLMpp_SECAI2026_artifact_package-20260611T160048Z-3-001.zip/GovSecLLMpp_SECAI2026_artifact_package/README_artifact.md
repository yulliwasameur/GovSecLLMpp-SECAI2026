# GovSecLLM++ SECAI 2026 Artifact Package

This repository contains the reproducibility artifacts for:

**GovSecLLM++: A Compliance-Aware Benchmark for Security Testing and Governance Evidence in LLM-Based Applications**

## Contents

- `paper/`: final paper source/PDF if available.
- `scenario_cards/`: scenario-suite metadata.
- `results/controlled_validation/`: controlled validation outputs when included.
- `results/groq_full_suite/`: hosted Groq full-suite outputs when included.
- `results/mini_multimodel/`: mini multi-model benchmark and rescoring outputs.
- `results/corrected_f2/`: corrected hidden-context confidentiality rerun.
- `results/adaptive_govsec_120/`: AdaptiveGovSec-120 raw outputs, errors, and summaries.
- `human_validation/`: two-human-confirmed validation sample.
- `tables_for_latex/`: CSV tables used to generate paper tables.
- `scripts/`: scoring and packaging scripts.
- `metadata/`: checksums and manifest.

## Main Experimental Components

1. Controlled validation:
   - 210 scenario cards
   - 2 deterministic reference backends
   - 5 configurations
   - 3 repetitions
   - 6300 runs

2. Hosted Groq full-suite evaluation:
   - 210 scenario cards
   - 5 configurations
   - 1050 real-backend runs

3. Mini multi-model benchmark:
   - 30 scenarios
   - API-accessible backends
   - strict rescoring to separate unsafe output from safe refusal

4. Corrected F2 rerun:
   - secrets appear only in hidden application context
   - no user-provided canary echoing
   - 24 valid calls across Groq, Mistral, and Cerebras

5. AdaptiveGovSec-120:
   - 120 adaptive scenarios
   - 4 API-accessible backends
   - 478 successful responses out of 480 expected calls
   - 2 provider-side errors logged separately

## Important Notes

All secrets, records, tools, policies, and documents are synthetic.
No real confidential or personal data is included.

Smoke-test executions are included only for pipeline validation when available and are excluded from reported full-run metrics.

The benchmark provides technical and governance-oriented evidence; it is not a legal certification of AI Act or ISO/IEC compliance.
