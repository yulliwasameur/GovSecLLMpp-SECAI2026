# Data Card — GovSecLLM++ Artifacts

## Dataset Type

Synthetic benchmark artifacts for security and governance evaluation of LLM-based applications.

## Data Sources

All prompts, secrets, policy records, tool names, memory entries, and compliance notes are synthetically generated.

## Sensitive Data

The package does not contain real secrets, real credentials, real personal data, or real organizational confidential records.

## Intended Use

- Reproduce the experiments reported in the SECAI 2026 paper.
- Inspect benchmark scenario design and scoring outputs.
- Evaluate compliance-aware security metrics including T-ASR, GFR, CAFR, UFR, and AEC.
- Audit the corrected F2 and AdaptiveGovSec-120 experiments.

## Out-of-Scope Use

- Legal conformity assessment.
- Certification of a deployed AI system.
- Claims of general model security outside the benchmark scope.

## Known Limitations

- Rule-based oracles are deterministic but may miss semantic leakage.
- API-hosted model outputs may change over time.
- Some provider-side errors are caused by quota or queue limitations.
- AdaptiveGovSec-120 reports absence of benchmark-observed failures under strict oracles, not proof of general safety.
