# Paper Files

The final paper source and PDF were not automatically found by the packaging script.

Recommended manual action before GitHub/Zenodo release:

1. Add the final `main.tex` used for Overleaf compilation.
2. Add the final compiled PDF as `SECAI_2026_GovSecLLMpp_submission.pdf`.

The artifact package remains usable without these files because experimental outputs, summaries, metadata, and reproducibility notes are included.
