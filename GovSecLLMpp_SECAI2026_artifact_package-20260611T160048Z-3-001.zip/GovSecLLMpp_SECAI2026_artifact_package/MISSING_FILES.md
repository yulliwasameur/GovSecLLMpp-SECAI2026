# Missing Files Report

This package was patched after initial packaging.

Resolved or documented items:

- `strict_failure_examples.csv`: generated as an empty CSV because AdaptiveGovSec-120 produced zero strict failure examples.
- `human_validation_sample_mini_30x5_verified_by_two_human_annotators.xlsx`: generated as a summary workbook if the full row-level workbook was not available in Colab.
- `paper/main.tex` and final PDF: optional; add manually if available.

Before final Zenodo upload, the recommended manual additions are:

1. final `main.tex`;
2. final compiled PDF;
3. full row-level human-validation workbook, if available.
